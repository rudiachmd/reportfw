<?php
class karyawan_model extends CI_Model
{ }
