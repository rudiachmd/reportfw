<?php
class karyawan_asking_model extends CI_Model
{ }
