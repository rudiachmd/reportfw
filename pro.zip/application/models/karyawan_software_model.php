<?php
class karyawan_software_model extends CI_Model
{ }
