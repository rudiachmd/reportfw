<?php
class karyawan_hardware_model extends CI_Model
{ }
